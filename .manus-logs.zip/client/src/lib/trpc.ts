﻿export const trpc = { useQuery: () => ({ data: null, isLoading: false }) };
